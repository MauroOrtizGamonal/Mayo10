package com.softtek.Mayo07.Servicio;

import com.softtek.Mayo07.Modelo.Lugar;

import java.util.List;

public interface ILugarServicio extends ICRUD<Lugar, Integer>{}
