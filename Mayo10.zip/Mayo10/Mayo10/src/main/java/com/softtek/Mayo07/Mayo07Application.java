package com.softtek.Mayo07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mayo07Application {

	public static void main(String[] args) {
		SpringApplication.run(Mayo07Application.class, args);
	}

}
