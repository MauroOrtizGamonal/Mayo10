package com.softtek.Mayo07.Repositorio;

import com.softtek.Mayo07.Modelo.Producto;

public interface IProductoRepositorio extends IGenericoRepositorio<Producto, Integer> {
}
