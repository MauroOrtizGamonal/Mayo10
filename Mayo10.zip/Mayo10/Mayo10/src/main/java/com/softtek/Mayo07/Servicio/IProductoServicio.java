package com.softtek.Mayo07.Servicio;

import com.softtek.Mayo07.Modelo.Producto;

import java.util.List;

public interface IProductoServicio extends ICRUD<Producto, Integer>{}
