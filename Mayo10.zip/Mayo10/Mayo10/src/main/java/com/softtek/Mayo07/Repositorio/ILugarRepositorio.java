package com.softtek.Mayo07.Repositorio;

import com.softtek.Mayo07.Modelo.Lugar;

public interface ILugarRepositorio extends IGenericoRepositorio<Lugar,Integer> {
}
