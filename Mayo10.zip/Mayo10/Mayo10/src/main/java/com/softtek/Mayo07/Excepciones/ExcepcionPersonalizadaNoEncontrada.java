package com.softtek.Mayo07.Excepciones;

public class ExcepcionPersonalizadaNoEncontrada extends RuntimeException{
    public ExcepcionPersonalizadaNoEncontrada(String message){
        super(message);
    }
}
